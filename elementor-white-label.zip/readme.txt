=== Elementor White Label ===
Contributors: namncn
Donate link: https://namncn.com/donate/
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl.html
Tags: elementor, elementor white label
Tested up to: 4.9.6
Requires PHP: 5.6.3

White Label for Elementor Page Builder.

== Description ==

White Label for Elementor Page Builder.

== Installation ==

=== From within WordPress ===

1. Visit 'Plugins > Add New'
2. Search for 'Elementor White Label'
3. Activate Elementor White Label from your Plugins page.
4. Go to "after activation" below.

=== Manually ===

1. Upload the `elementor-white-label` folder to the `/wp-content/plugins/` directory
2. Activate the Elementor White Label plugin through the 'Plugins' menu in WordPress
3. Go to "after activation" below.

== Frequently Asked Questions ==

You'll find answers to many of your questions on (https://namncn.com/plugins/elementor-white-label/).

== Screenshots ==

== Changelog ==

= 1.0.1 =
* Fix bugs.

= 1.0.0 =
* First release.
